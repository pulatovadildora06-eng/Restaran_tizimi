RESTORAN TIZIMI — WEB VERSIYA

Ishga tushirish:
1. pip install -r requirements.txt
2. streamlit run app.py

Internetga chiqarish:
GitHub -> yangi repository -> shu papkadagi fayllarni yuklash -> Streamlit Community Cloud orqali app.py ni tanlash.

Eslatma: bepul Streamlit Cloud'da lokal JSON fayl doimiy ma'lumotlar bazasi o'rnini bosmaydi. O'quv/demo loyihasi uchun mos. Doimiy onlayn ma'lumotlar uchun keyin Supabase kabi baza ulash mumkin.
