import streamlit as st
import json, os
from datetime import date, datetime

st.set_page_config(page_title='Restoran tizimi', page_icon='🍽️', layout='wide')

BASE=os.path.dirname(os.path.abspath(__file__))
DATA=os.path.join(BASE,'restoran_malumotlar.json')
PRICES=os.path.join(BASE,'narxlar.json')
IMG=os.path.join(BASE,'rasmlar')
ADMIN_LOGIN='pulatovadildora'
ADMIN_PAROL='pulatova_d06'
KARTA='5614 6812 9053 9174'
OLDINDAN=0.50
BEKOR_TELEFON='+998901234567'

RANG='#B85042'

JOYLAR=[]
for i in range(1,5): JOYLAR.append({'id':f'1Q-S{i}','qavat':1,'turi':'Stol','raqam':i,'sigim':4})
for i in range(5,8): JOYLAR.append({'id':f'1Q-S{i}','qavat':1,'turi':'Stol','raqam':i,'sigim':2})
for i in range(1,4): JOYLAR.append({'id':f'2Q-K{i}','qavat':2,'turi':'Kabina','raqam':i,'sigim':4})
JOYLAR.append({'id':'2Q-K4','qavat':2,'turi':'Kabina','raqam':4,'sigim':8})

MENYU={
'Milliy taomlar':[
('Palov',45000,'taom_plov.png'),("Lag'mon",38000,'taom_lagmon.png'),('Manti',32000,'taom_manti.png'),('Shashlik',40000,'taom_shashlik.png'),('Norin',36000,'taom_norin.png'),('Dimlama',34000,'taom_dimlama.png'),('Kabob',42000,'taom_kabob.png'),('Somsa',12000,'taom_somsa.png'),('Tuxum barak',28000,'taom_tuxum_barak.png'),('Qozon kabob',48000,'taom_qozon_kabob.png')],
'Salatlar':[
('Olivye',18000,'salat_olivye.png'),('Sharqona salat',15000,'salat_sharqona_salat.png'),('Atsikaj',16000,'salat_atsikaj.png'),('Sezar',22000,'salat_sezar.png'),('Grek salati',20000,'salat_grek_salati.png')],
'Ichimliklar':[
('Choy (qora)',5000,None),('Yashil choy',6000,None),('Kofe (Americano)',10000,None),('Kofe (Latte)',12000,None),('Kakao',8000,None),('Cola',8000,None),('Fanta',8000,None),('Pepsi',8000,None),('Sprite',8000,None),('Suv (0.5 l)',5000,None),('Tabiiy sharbat',12000,None),('Kompot',8000,None),('Mors',8000,None),('Limonad',10000,None),('Ayran',7000,None),('Bonaqua (0.5 l)',15000,None),('Coca-Cola Zero',5000,None),('Fanta Zero',8000,None),('Pepsi Zero',8000,None)]}

if os.path.exists(PRICES):
    try:
        saved=json.load(open(PRICES,encoding='utf-8'))
        MENYU={k:[(n,saved.get(n,p),r) for n,p,r in v] for k,v in MENYU.items()}
    except: pass

def money(x): return f'{x:,.0f}'.replace(',',' ')+' so\'m'
def load():
    if not os.path.exists(DATA): return []
    try:return json.load(open(DATA,encoding='utf-8'))
    except:return []
def save(x):
    with open(DATA,'w',encoding='utf-8') as f: json.dump(x,f,ensure_ascii=False,indent=2)
def busy(bs,jid,d,t):
    return any(b['joy_id']==jid and b['sana']==str(d) and b['vaqt']==t and b['holat']!='Bekor qilingan' for b in bs)
def available(bs,typ,cap,d,t):
    return [j for j in JOYLAR if j['turi']==typ and j['sigim']==cap and not busy(bs,j['id'],d,t)]

def new_booking(bs,name,phone,d,t,cap,place,cart):
    total=sum(x['narx']*x['soni'] for x in cart)
    pre=round(total*OLDINDAN); rem=total-pre
    bid=max([b.get('id',0) for b in bs],default=0)+1
    b={'id':bid,'ism':name,'telefon':phone,'sana':str(d),'vaqt':t,'sigim':cap,'joy_id':place['id'],'joy_matni':f"{place['qavat']}-qavat, {place['turi']} №{place['raqam']}",'savat':cart,'jami_summa':total,'oldindan_tolov':pre,'qolgan_tolov':rem,'holat':'To\'lov kutilmoqda','yaratilgan_vaqt':datetime.now().strftime('%Y-%m-%d %H:%M')}
    bs.append(b); save(bs); return b

if 'cart' not in st.session_state: st.session_state.cart={}
if 'page' not in st.session_state: st.session_state.page='home'

st.markdown(f"<style>.main-title{{font-size:42px;font-weight:800;color:{RANG};}} .card{{padding:15px;border-radius:14px;border:1px solid #eaded7;background:#fff;}}</style>",unsafe_allow_html=True)

st.sidebar.title('🍽️ Restoran tizimi')
page=st.sidebar.radio('Bo‘lim', ['🏠 Bosh sahifa','👤 Mijoz','📋 Mening buyurtmalarim','🔐 Admin'])

if page=='🏠 Bosh sahifa':
    st.markdown('<div class="main-title">🍽️ RESTORAN TIZIMI</div>',unsafe_allow_html=True)
    st.write('Stol/kabina band qilish, oldindan buyurtma va to‘lov tizimi')
    st.image(os.path.join(IMG,'fon_qorongi.jpg'), use_container_width=True)
    st.info('Mijoz bo‘limidan joy va taomlarni tanlang. Admin bo‘limidan buyurtmalarni boshqaring.')

elif page=='👤 Mijoz':
    st.header('👤 Mijoz sifatida kirish')
    bs=load()
    c1,c2=st.columns(2)
    with c1:
        name=st.text_input('Ism-familiya')
        phone=st.text_input('Telefon raqam')
        d=st.date_input('Kelish sanasi',min_value=date.today())
        t=st.selectbox('Kelish vaqti',[f'{h:02d}:{m:02d}' for h in range(10,24) for m in range(0,60,5)])
    with c2:
        typ_label=st.selectbox('Joy turi',['Umumiy zal (1-qavat)','Kabina (2-qavat)'])
        typ='Stol' if typ_label.startswith('Umumiy') else 'Kabina'
        caps=sorted(set(j['sigim'] for j in JOYLAR if j['turi']==typ))
        cap=st.selectbox('Necha kishilik',caps)
        places=available(bs,typ,cap,d,t)
        if places:
            place=st.selectbox('Mavjud joy',[f"№{j['raqam']} — {j['sigim']} kishilik" for j in places])
            place=places[[f"№{j['raqam']} — {j['sigim']} kishilik" for j in places].index(place)]
            st.success(f"Bo‘sh joy: {place['qavat']}-qavat, {place['turi']} №{place['raqam']}")
        else:
            place=None; st.error('Bu sana va vaqtda mos bo‘sh joy qolmagan.')
    st.divider(); st.subheader('🍴 Menyu')
    cart={}
    for cat,items in MENYU.items():
        st.markdown(f'### {cat}')
        cols=st.columns(3)
        for i,(n,p,r) in enumerate(items):
            with cols[i%3]:
                if r and os.path.exists(os.path.join(IMG,r)): st.image(os.path.join(IMG,r),use_container_width=True)
                st.write(f'**{n}** — {money(p)}')
                q=st.number_input('Soni',min_value=0,max_value=20,value=0,key='q_'+n)
                if q: cart[n]={'ism':n,'narx':p,'soni':q}
    total=sum(x['narx']*x['soni'] for x in cart.values())
    st.divider(); st.subheader(f'🛒 Jami: {money(total)}')
    if total: st.info(f"Oldindan to‘lov (50%): {money(round(total*OLDINDAN))} | Qolgan: {money(total-round(total*OLDINDAN))}")
    if st.button('✅ Band qilish va buyurtma berish',type='primary',disabled=not(name and phone and place and total)):
        b=new_booking(bs,name,phone,d,t,cap,place,list(cart.values()))
        st.success(f"Buyurtma №{b['id']} yaratildi. Oldindan to‘lov: {money(b['oldindan_tolov'])}")
        st.info(f'💳 Karta: {KARTA}\n\nTo‘lovni amalga oshirgach, admin tasdiqlaydi.')

elif page=='📋 Mening buyurtmalarim':
    st.header('📋 Mening buyurtmalarim')
    phone=st.text_input('Buyurtma bergan telefon raqamingiz')
    if phone:
        bs=[b for b in load() if b.get('telefon')==phone]
        if not bs: st.warning('Bu raqam bilan buyurtma topilmadi.')
        for b in reversed(bs):
            with st.expander(f"№{b['id']} — {b['sana']} {b['vaqt']} — {b['holat']}"):
                st.write('Joy:',b['joy_matni']); st.write('Jami:',money(b['jami_summa'])); st.write('Oldindan:',money(b['oldindan_tolov'])); st.write('Qolgan:',money(b['qolgan_tolov']))
                st.write('Taomlar:',', '.join(f"{x['ism']} × {x['soni']}" for x in b['savat']))
                if b['holat']!='Bekor qilingan': st.caption(f'Bekor qilish uchun: {BEKOR_TELEFON}')

elif page=='🔐 Admin':
    st.header('🔐 Admin panel')
    if 'admin_ok' not in st.session_state: st.session_state.admin_ok=False
    if not st.session_state.admin_ok:
        l=st.text_input('Login'); p=st.text_input('Parol',type='password')
        if st.button('Kirish'):
            if l==ADMIN_LOGIN and p==ADMIN_PAROL: st.session_state.admin_ok=True; st.rerun()
            else: st.error('Login yoki parol noto‘g‘ri.')
    else:
        if st.button('Chiqish'): st.session_state.admin_ok=False; st.rerun()
        bs=load(); st.subheader(f'📦 Buyurtmalar: {len(bs)}')
        for b in reversed(bs):
            with st.expander(f"№{b['id']} | {b['ism']} | {b['sana']} {b['vaqt']} | {b['holat']}"):
                st.write(f"Telefon: {b['telefon']}  |  Joy: {b['joy_matni']}")
                st.write(f"Jami: {money(b['jami_summa'])} | Oldindan: {money(b['oldindan_tolov'])} | Qolgan: {money(b['qolgan_tolov'])}")
                st.write(', '.join(f"{x['ism']} × {x['soni']}" for x in b['savat']))
                c1,c2=st.columns(2)
                if b['holat']!='Tasdiqlangan' and b['holat']!='Bekor qilingan':
                    if c1.button('✅ Tasdiqlash',key='ok'+str(b['id'])):
                        b['holat']='Tasdiqlangan'; save(bs); st.rerun()
                if b['holat']!='Bekor qilingan':
                    if c2.button('❌ Bekor qilish',key='no'+str(b['id'])):
                        b['holat']='Bekor qilingan'; save(bs); st.rerun()
        st.divider(); st.subheader('💰 Menyu narxlarini o‘zgartirish')
        changed=False; newprices={}
        for cat,items in MENYU.items():
            st.write('**'+cat+'**')
            for n,p,r in items:
                newprices[n]=st.number_input(n,min_value=0,value=int(p),step=1000,key='price_'+n)
        if st.button('💾 Narxlarni saqlash'):
            json.dump(newprices,open(PRICES,'w',encoding='utf-8'),ensure_ascii=False,indent=2); st.success('Narxlar saqlandi.')
